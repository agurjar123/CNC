

% Define input matrix
data = randn(100, 1000); % example 2D matrix of 100 neurons over 1000 time steps
% example 2d matrix of 100 neurons over 1000 time steps
%

% Define colormap
cmap = parula(256); % use a colormap with 256 colors

% Compute the frequency of each time trace
freq = sum(data, 1) ./ size(data, 1);

%round
freq_scaled = round(255 * (freq - min(freq)) / (max(freq) - min(freq))) + 1;

% Create the raster map
figure;
imagesc(freq_scaled); 
colormap(cmap); % set the colormap
xlabel('Time'); % set the x-axis label
ylabel('Neurons'); % set the y-axis label
colorbar; % add a colorbar